# Laboratorul 3 — Monitorizare Prometheus & Grafana

**Aplicație monitorizată:** scraper Python pentru anunțuri [999.md](https://999.md) (categorie mașini), salvează în SQLite doar anunțurile noi.

## Rulare

```bash
cd lab3/code
./run.sh
```

Oprire:

```bash
cd lab3/code/default
./stop_cluster.sh
```

## Monitorizare

| Serviciu | URL |
|----------|-----|
| Grafana | http://localhost:3000 — `admin` / `admin` |
| Prometheus | http://localhost:9090 |
| Metrici scraper | http://localhost:8000/metrics |

Dashboard: **ADA Lab3 - 999.md Scraper** (provisionat automat).

### Ce vezi în Grafana

1. **CPU / memorie / disk** — `node-exporter`
2. **Request-uri scraper / min** — `rate(scraper_http_requests_total[1m])*60`
3. **Memorie proces scraper** — `process_resident_memory_bytes{job="scraper"}`
4. **Anunțuri în DB** — `scraper_adverts_in_db`

## Implementare scraper

- Playwright (Chromium headless) — 999.md încarcă anunțurile prin JavaScript
- La fiecare `SCRAPE_INTERVAL_SECONDS` (implicit 120s): citește linkuri `/ro/<id>`, inserează doar ID-uri noi
- Baza: SQLite în volumul Docker `scraper_data`

## Legătură Lab 1–2

| Lab | Rol |
|-----|-----|
| Lab 1 | performanță CPU (OpenMP/MPI) |
| Lab 2 | decuplare mesaje (RabbitMQ) |
| Lab 3 | observabilitate: resurse nod + aplicație web (scraper) |
