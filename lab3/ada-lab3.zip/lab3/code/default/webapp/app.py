from flask import Flask
from prometheus_client import Counter, generate_latest, CONTENT_TYPE_LATEST

app = Flask(__name__)
requests_total = Counter("http_requests_total", "HTTP requests", ["method", "endpoint"])


@app.route("/")
def home():
    requests_total.labels("GET", "/").inc()
    return "ADA Lab 3 - aplicatie web demo pentru Prometheus/Grafana"


@app.route("/health")
def health():
    requests_total.labels("GET", "/health").inc()
    return "ok"


@app.route("/metrics")
def metrics():
    return generate_latest(), 200, {"Content-Type": CONTENT_TYPE_LATEST}


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
